package com.entities;

import java.util.List;
import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Users {
	
	@Id
	private int userId;
	 
	private String name;
	private	 String emailId;
	private	 String userName;
	private	 String password;
	 
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Users( String name, String emailId, String userName, String password) {
		super();
		this.userId =new Random().nextInt(100000);
		this.name = name;
		this.emailId = emailId;
		this.userName = userName;
		this.password = password;
	
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId() {
		this.userId = new Random().nextInt(100000);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "Users [userId=" + userId + ", name=" + name + ", emailId=" + emailId + ", userName=" + userName
				+ ", password=" + password + "]";
	}
	 
	 
	
	 
	 
	 

}
