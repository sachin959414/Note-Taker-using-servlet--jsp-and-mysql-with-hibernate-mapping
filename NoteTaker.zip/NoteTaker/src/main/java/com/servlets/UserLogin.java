package com.servlets;

import java.io.IOException;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Parameter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import com.entities.Users;
import com.helper.FactoryProvider;

/**
 * Servlet implementation class UserLogin
 */
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username1=request.getParameter("username");
		String password1=request.getParameter("password");
		int userId=0;
		Session s=FactoryProvider.getFactory().openSession();
		Transaction tx=s.beginTransaction();
        
		NativeQuery query =s.createSQLQuery("select userId from users where userName=? and password=?;");
		query.setString(1, username1);
		query.setString(2, password1);
		

		if(!query.equals(null))
		{
	
			try
			{
userId=(Integer)query.getSingleResult();


			}catch (NoResultException e) {
				
				response.getWriter().println("pls provide right username and password");
			}
         

		}
		else
		{
response.getWriter().println("Pls choose right user name and password");
		}
	
		tx.commit();
		s.close();
		
		if(userId>0)
		{
			HttpSession session=request.getSession();
			session.setAttribute("userId",userId);
			
			Cookie cookie=new Cookie("username",username1);
			cookie.setMaxAge(7*24*60*60);
			response.addCookie(cookie);
			response.sendRedirect("add_notes.jsp");
			
			
			
		}
		else
		{
			
		}
	}

}
