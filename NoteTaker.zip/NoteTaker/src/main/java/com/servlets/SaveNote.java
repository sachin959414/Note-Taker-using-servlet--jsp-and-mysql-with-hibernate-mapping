package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entities.Note;
import com.entities.Users;
import com.helper.FactoryProvider;


/**
 * Servlet implementation class SaveNote
 */
public class SaveNote extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String title=request.getParameter("title");
		String content=request.getParameter("content");
		HttpSession session=request.getSession();
        int userId=(Integer)session.getAttribute("userId");
		Note note=new Note(title,content,new Date());
		
		//System.out.println(note.getId()+":::"+note.getTitle());
		
		
		
		 Session s=FactoryProvider.getFactory().openSession();
		 Transaction tx=s.beginTransaction();
		 Users user=s.get(Users.class, userId);
		 note.setUsers(user);
		 int a=(Integer)s.save(note);
		 tx.commit();
		 
		 s.close();
		 if(a>0)
		 {
		 response.setContentType("text/html");
		 PrintWriter out=response.getWriter();
		 out.println("<h1>Note is added succesfully</h1>");
		 out.println("<h1 style='text-align:center;'><a href='shownotes'>View All Notes</a></h1>");
		 }
		 
	}

}
