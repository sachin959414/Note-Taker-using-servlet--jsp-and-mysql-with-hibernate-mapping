package com.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import com.entities.Note;
import com.entities.Users;
import com.helper.FactoryProvider;

/**
 * Servlet implementation class ShowNotes
 */
public class ShowNotes extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

if(request.getSession().getAttribute("userId")==null)
{
	System.out.println("In if");
	response.sendRedirect("login.jsp");
}
else
{
		
		HttpSession session=request.getSession();
		int userId=(Integer)session.getAttribute("userId");
		List<Note> notes;
		Session s=FactoryProvider.getFactory().openSession();
		Transaction tx=s.beginTransaction();
		Users user=s.get(Users.class,userId);
		System.out.println(user.getName());
		Query<Note> query=s.createQuery("from Note where userId=:user1");
	    query.setParameter("user1", user);
	
	     notes=query.getResultList();
		
		tx.commit();
		s.close();
		
		Note note=notes.get(0);
		System.out.println(note);
		
		request.setAttribute("notes",notes);
		request.getRequestDispatcher("all_notes.jsp").forward(request,response);
		
		
		
		
		
	}

}
}